import os
import logging
import requests
import sys
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")

if not TELEGRAM_BOT_TOKEN:
    print("ERROR: TELEGRAM_BOT_TOKEN environment variable not found.")
    sys.exit(1)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def query_groq(user_text: str) -> str:
    if not GROQ_API_KEY:
        return "(AI API key not configured.)"

    url = "https://api.groq.com/openai/v1/chat/completions"
    payload = {
        "model": "llama3-8b-8192",
        "messages": [{"role": "user", "content": user_text}],
    }
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }

    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        choices = data.get("choices") or []
        if len(choices) and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            content = message.get("content") or "(no content returned)"
            return content
        if "text" in data:
            return data.get("text")
        return str(data)
    except Exception as e:
        logger.exception("Error calling Groq API: %s", e)
        return "(Error: failed to contact AI service.)"

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_text = update.message.text or ""
    user = update.effective_user

    logger.info("Message from %s: %s", user.username or user.id, user_text)

    try:
        await update.message.reply_chat_action("typing")
    except Exception:
        pass

    ai_reply = query_groq(user_text)

    MAX_CHUNK = 4000
    if len(ai_reply) <= MAX_CHUNK:
        await update.message.reply_text(ai_reply)
    else:
        for i in range(0, len(ai_reply), MAX_CHUNK):
            await update.message.reply_text(ai_reply[i : i + MAX_CHUNK])

async def start_bot():
    application = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    application.add_handler(
        MessageHandler(
            filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND,
            handle_message
        )
    )

    logger.info("Starting bot with polling...")
    await application.initialize()
    await application.start()
    await application.updater.start_polling()
    logger.info("Bot started. Press Ctrl+C to stop.")
    await application.updater.idle()

if __name__ == "__main__":
    import asyncio
    try:
        asyncio.run(start_bot())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped")
